package com.vueo.tv.library

import com.vueo.tv.ui.motion.*
import android.content.Context
import com.vueo.shared.core.diagnostics.PerformanceDiagnostics
import android.view.KeyEvent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vueo.shared.core.media.MediaItem
import com.vueo.shared.core.storage.LibraryHistoryPresentation
import com.vueo.shared.core.storage.LibraryPlaybackEntry
import com.vueo.tv.core.TvRuntime
import com.vueo.tv.ui.TvDesign
import com.vueo.tv.ui.TvNetworkImage
import com.vueo.tv.ui.TvPosterActionDialog
import com.vueo.tv.ui.motion.TvMotion
import com.vueo.tv.home.MODERN_HOME_CONTENT_START_PADDING
import com.vueo.tv.home.TiveoPageContentFocus
import com.vueo.tv.home.TiveoTopBarState
import com.vueo.tv.home.TiveoTopBarHeight
import com.vueo.tv.ui.tvPosterActivation
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged

private const val LIBRARY_UI_PREFS = "vueo_library_ui"
private const val LIBRARY_GRID_VIEW_KEY = "grid_view"
private const val LIBRARY_HEADER_ITEMS = 1
private const val LIBRARY_TARGET_POSTER_WIDTH_DP = 126f
private const val LIBRARY_GRID_GAP_DP = 16f

/**
 * TV-only ephemeral focus/scroll memory.
 *
 * This deliberately stores no library data. Favorites continues to come from the
 * shared LibraryStore used by Mobile. The memory only lets the manual TV route
 * switch return to the same Library item after Detail without creating another
 * source of truth.
 */
private object TvLibraryFocusMemory {
    var historySelected: Boolean = false
    var lastTarget: String = "section"
    var lastMediaKey: String? = null
    var firstVisibleItemIndex: Int = 0
    var firstVisibleItemScrollOffset: Int = 0
}

@Suppress("UNUSED_PARAMETER")
@Composable
internal fun TvLibraryScreen(
    runtime: TvRuntime,
    refreshToken: Int,
    active: Boolean = true,
    topBar: TiveoTopBarState,
    onOpenMedia: (MediaItem) -> Unit,
    onResume: (LibraryPlaybackEntry) -> Unit,
    onBack: () -> Unit,
) {
    val profileId = runtime.profileStore.activeProfileId()
    val kidsLimit = runtime.profileStore.kidsAgeLimit()
    var historySelected by remember(profileId) { mutableStateOf(TvLibraryFocusMemory.historySelected) }
    var libraryRevision by remember { mutableStateOf(0) }
    var actionMedia by remember { mutableStateOf<MediaItem?>(null) }
    var favorites by remember(profileId, kidsLimit) { mutableStateOf(emptyList<MediaItem>()) }
    var history by remember(profileId, kidsLimit) { mutableStateOf(emptyList<LibraryPlaybackEntry>()) }
    var loading by remember(profileId, kidsLimit) { mutableStateOf(true) }
    var loadFailed by remember(profileId, kidsLimit) { mutableStateOf(false) }
    LaunchedEffect(refreshToken, libraryRevision, profileId, kidsLimit) {
        loading = true
        loadFailed = false
        val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                if (runtime.profileStore.activeProfileId() != profileId) return@runCatching null
                (runtime.libraryStore.watchlist() to LibraryHistoryPresentation.latestTitles(runtime.libraryStore.history()))
                    .takeIf { runtime.profileStore.activeProfileId() == profileId }
            }
        }
        result.onSuccess { fresh -> if (fresh != null) { favorites = fresh.first; history = fresh.second } }
            .onFailure { loadFailed = true }
        loading = false
    }
    val watchlist = if (historySelected) history.map { it.media } else favorites
    val historyCaptions = remember(history) {
        history.associate { libraryMediaKey(it.media) to LibraryHistoryPresentation.caption(it) }
    }
    val context = LocalContext.current
    val historyScope = rememberCoroutineScope()
    var deleteHistoryError by remember(profileId) { mutableStateOf(false) }
    val libraryUiPreferences = remember {
        context.getSharedPreferences(LIBRARY_UI_PREFS, Context.MODE_PRIVATE)
    }

    var gridView by remember {
        mutableStateOf(libraryUiPreferences.getBoolean(LIBRARY_GRID_VIEW_KEY, true))
    }

    val viewModeRequester = remember { FocusRequester() }
    val favoritesRequester = remember { FocusRequester() }
    val historyRequester = remember { FocusRequester() }

    val mediaKeys = remember(watchlist) {
        watchlist.map(::libraryMediaKey)
    }
    val mediaRequesters = remember(mediaKeys) {
        mediaKeys.associateWith { FocusRequester() }
    }

    val initialMaxIndex = if (watchlist.isEmpty()) {
        LIBRARY_HEADER_ITEMS
    } else {
        watchlist.size + LIBRARY_HEADER_ITEMS - 1
    }
    val gridState = rememberLazyGridState(
        initialFirstVisibleItemIndex =
            TvLibraryFocusMemory.firstVisibleItemIndex.coerceIn(0, initialMaxIndex),
        initialFirstVisibleItemScrollOffset =
            TvLibraryFocusMemory.firstVisibleItemScrollOffset.coerceAtLeast(0),
    )

    var lastTarget by remember { mutableStateOf(TvLibraryFocusMemory.lastTarget) }
    var lastMediaKey by remember { mutableStateOf(TvLibraryFocusMemory.lastMediaKey) }

    fun rememberTarget(target: String, mediaKey: String? = lastMediaKey) {
        lastTarget = target
        lastMediaKey = mediaKey
        TvLibraryFocusMemory.lastTarget = target
        TvLibraryFocusMemory.lastMediaKey = mediaKey
    }

    fun focusTopBar() {
        topBar.focus("Library")
    }

    BackHandler(enabled = active && actionMedia == null) {
        PerformanceDiagnostics.captureRuntimeEvent(
            "TV_TAB_BACK tab=Library action=${if (topBar.hasFocus) "home" else "open_navigation"}"
        )
        if (topBar.hasFocus) onBack() else focusTopBar()
    }

    fun requestHeaderFocus(): Boolean =
        runCatching {
            (if (historySelected) historyRequester else favoritesRequester).requestFocus()
        }.getOrDefault(false)

    fun requestFirstMediaFocus(): Boolean {
        if (watchlist.isEmpty()) return false
        val key = mediaKeys.firstOrNull() ?: return false
        return runCatching {
            mediaRequesters.getValue(key).requestFocus()
            true
        }.getOrDefault(false)
    }

    fun restoreContentFocus(): Boolean {
        val requester = when (lastTarget) {
            "view" -> viewModeRequester
            "item" -> lastMediaKey?.let(mediaRequesters::get)
            else -> null
        }
        val restored = runCatching { requester?.requestFocus() == true }.getOrDefault(false)
        return restored || requestHeaderFocus()
    }

    LaunchedEffect(historySelected) {
        TvLibraryFocusMemory.historySelected = historySelected
    }

    LaunchedEffect(gridState) {
        snapshotFlow {
            gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset
        }
            .distinctUntilChanged()
            .collect { (index, offset) ->
                TvLibraryFocusMemory.firstVisibleItemIndex = index
                TvLibraryFocusMemory.firstVisibleItemScrollOffset = offset
            }
    }

    // Vueo-reference focus restoration: poster first when returning from
    // Detail, otherwise the primary Library selector owns initial focus.
    LaunchedEffect(active, mediaKeys, gridView, historySelected) {
        if (!active || topBar.hasFocus) return@LaunchedEffect
        delay(110)
        if (topBar.hasFocus) return@LaunchedEffect
        var restored = false
        if (lastTarget == "item") {
            val key = lastMediaKey
            val mediaIndex = key?.let(mediaKeys::indexOf)?.takeIf { it >= 0 }
            val requester = key?.let(mediaRequesters::get)
            if (mediaIndex != null && requester != null) {
                if (
                    TvLibraryFocusMemory.firstVisibleItemIndex == 0 &&
                    TvLibraryFocusMemory.firstVisibleItemScrollOffset == 0
                ) {
                    runCatching { gridState.scrollToItem(mediaIndex + LIBRARY_HEADER_ITEMS) }
                }
                if (topBar.hasFocus) return@LaunchedEffect
                restored = runCatching { requester.requestFocus() }.getOrDefault(false)
                if (!restored) {
                    delay(20)
                    if (topBar.hasFocus) return@LaunchedEffect
                    restored = runCatching { requester.requestFocus() }.getOrDefault(false)
                }
            }
        }

        if (!restored) {
            if (lastTarget == "section") gridState.scrollToItem(0)
            restored = restoreContentFocus()
        }
        if (!restored) {
            gridState.scrollToItem(0)
            delay(20)
            if (!topBar.hasFocus) requestHeaderFocus()
        }
    }

    val contentStartPadding = MODERN_HOME_CONTENT_START_PADDING

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(TvDesign.Black),
    ) {
        val availableWidthDp = (maxWidth.value - contentStartPadding.value * 2).coerceAtLeast(420f)
        val gridColumns =
            ((availableWidthDp + LIBRARY_GRID_GAP_DP) /
                (LIBRARY_TARGET_POSTER_WIDTH_DP + LIBRARY_GRID_GAP_DP))
                .toInt()
                .coerceIn(4, 6)

        LazyVerticalGrid(
            columns = GridCells.Fixed(gridColumns),
            state = gridState,
            modifier = Modifier.fillMaxSize().padding(top = TiveoTopBarHeight),
            contentPadding = PaddingValues(
                start = contentStartPadding,
                end = contentStartPadding,
                top = 10.dp,
                bottom = 48.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            item(
                key = "library-header",
                span = { GridItemSpan(maxLineSpan) },
            ) {
                Column(
                    modifier = Modifier.onPreviewKeyEvent { event ->
                        if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                            focusTopBar()
                            true
                        } else {
                            false
                        }
                    },
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            listOf("Saved", "History").forEachIndexed { index, label ->
                                val selected = historySelected == (index == 1)
                                LibraryViewModeButton(
                                    gridView = gridView,
                                    label = label,
                                    selected = selected,
                                    requester = if (index == 0) favoritesRequester else historyRequester,
                                    onFocused = {
                                        if (!selected) {
                                            historySelected = index == 1
                                            TvLibraryFocusMemory.firstVisibleItemIndex = 0
                                            TvLibraryFocusMemory.firstVisibleItemScrollOffset = 0
                                        }
                                        if (!topBar.hasFocus) rememberTarget("section")
                                    },
                                    onToggle = {
                                        if (!selected) {
                                            historySelected = index == 1
                                            TvLibraryFocusMemory.firstVisibleItemIndex = 0
                                            TvLibraryFocusMemory.firstVisibleItemScrollOffset = 0
                                            rememberTarget("section")
                                        }
                                    },
                                    onLeft = {
                                        if (index == 0) focusTopBar() else favoritesRequester.requestFocus()
                                        true
                                    },
                                    onRight = {
                                        if (index == 0) historyRequester.requestFocus() else viewModeRequester.requestFocus()
                                        true
                                    },
                                    onDown = ::requestFirstMediaFocus,
                                )
                            }
                        }
                        LibraryViewModeButton(
                            gridView = gridView,
                            requester = viewModeRequester,
                            onFocused = {
                                if (!topBar.hasFocus) rememberTarget("view")
                            },
                            onToggle = {
                                val nextGridView = !gridView
                                gridView = nextGridView
                                libraryUiPreferences
                                    .edit()
                                    .putBoolean(LIBRARY_GRID_VIEW_KEY, nextGridView)
                                    .apply()
                                rememberTarget("view")
                            },
                            onLeft = {
                                (if (historySelected) historyRequester else favoritesRequester).requestFocus()
                                true
                            },
                            onDown = ::requestFirstMediaFocus,
                        )
                    }
                    if (deleteHistoryError) Text("Couldn't delete history. Try again.", color = TvDesign.Muted, fontSize = 12.sp)
                }
            }

            when {
                watchlist.isEmpty() -> {
                    item(
                        key = "library-saved-empty",
                        span = { GridItemSpan(maxLineSpan) },
                    ) {
                        LibraryEmptyState(
                            title = when {
                                loading -> "Loading My List…"
                                loadFailed -> "Couldn't load My List"
                                historySelected -> "No watch history yet"
                                else -> "Your list is empty"
                            },
                            body = when {
                                loading -> "Please wait."
                                loadFailed -> "Reopen My List to try again."
                                historySelected -> "Titles you watch will appear here."
                                else -> "Titles you add to My List will appear here."
                            },
                        )
                    }
                }

                gridView -> {
                    watchlist.forEachIndexed { index, media ->
                        val key = libraryMediaKey(media)
                        item(key = "library-grid:$key") {
                            LibraryPosterCard(
                                media = media,
                                historyCaption = if (historySelected) historyCaptions[key] else null,
                                requester = mediaRequesters.getValue(key),
                                onFocused = {
                                    if (!topBar.hasFocus) rememberTarget("item", key)
                                },
                                onClick = {
                                    TvLibraryFocusMemory.firstVisibleItemIndex =
                                        gridState.firstVisibleItemIndex
                                    TvLibraryFocusMemory.firstVisibleItemScrollOffset =
                                        gridState.firstVisibleItemScrollOffset
                                    rememberTarget("item", key)
                                    onOpenMedia(media)
                                },
                                onLongClick = { actionMedia = media },
                                onUpFromFirstRow = if (index < gridColumns) {
                                    {
                                        requestHeaderFocus()
                                    }
                                } else null,
                                onLeftFromFirstColumn = if (index % gridColumns == 0) {
                                    ::focusTopBar
                                } else null,
                                blockRight =
                                    index % gridColumns == gridColumns - 1 ||
                                        index == watchlist.lastIndex,
                            )
                        }
                    }
                }

                else -> {
                    watchlist.forEachIndexed { index, media ->
                        val key = libraryMediaKey(media)
                        item(
                            key = "library-list:$key",
                            span = { GridItemSpan(maxLineSpan) },
                        ) {
                            LibraryListRow(
                                media = media,
                                historyCaption = if (historySelected) historyCaptions[key] else null,
                                requester = mediaRequesters.getValue(key),
                                onFocused = {
                                    if (!topBar.hasFocus) rememberTarget("item", key)
                                },
                                onClick = {
                                    TvLibraryFocusMemory.firstVisibleItemIndex =
                                        gridState.firstVisibleItemIndex
                                    TvLibraryFocusMemory.firstVisibleItemScrollOffset =
                                        gridState.firstVisibleItemScrollOffset
                                    rememberTarget("item", key)
                                    onOpenMedia(media)
                                },
                                onLongClick = { actionMedia = media },
                                onLeft = ::focusTopBar,
                                onUpFromFirst = if (index == 0) {
                                    { requestHeaderFocus() }
                                } else null,
                            )
                        }
                    }
                }
            }
        }

        TiveoPageContentFocus(
            topBar = topBar,
            tab = "Library",
            active = active && actionMedia == null,
            onReturnToContent = {
                if (!restoreContentFocus()) {
                    historyScope.launch {
                        gridState.scrollToItem(0)
                        if (topBar.focusedTab == "Library") requestHeaderFocus()
                    }
                }
            },
        )
    }

    actionMedia?.let { media ->
        TvPosterActionDialog(
            media = media,
            libraryStore = runtime.libraryStore,
            onOpenDetails = { onOpenMedia(media) },
            onChanged = { libraryRevision += 1 },
            onDismiss = { actionMedia = null },
            onDeleteHistory = if (historySelected) ({
                deleteHistoryError = false
                historyScope.launch {
                    val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        runCatching { com.vueo.shared.core.storage.LibraryStore(context, profileIdOverride = profileId).resetTitleHistory(media) }
                    }
                    if (result.isSuccess) {
                        TvLibraryFocusMemory.firstVisibleItemIndex = 0
                        TvLibraryFocusMemory.firstVisibleItemScrollOffset = 0
                        rememberTarget("section")
                        libraryRevision += 1
                    } else deleteHistoryError = true
                }
            }) else null,
        )
    }

    // `onResume` stays in the existing route contract for compatibility.
    // Both Library sections open details; player resume stays on the detail page.
}

@Composable
private fun LibraryViewModeButton(
    gridView: Boolean,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onToggle: () -> Unit,
    onLeft: () -> Boolean,
    onDown: () -> Boolean,
    label: String? = null,
    selected: Boolean = false,
    onRight: () -> Boolean = { true },
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) tvTunedFocusScale(1.02f) else 1f,
        animationSpec = tvTunedSpec(TvMotionGroup.FOCUS, focused, tween(
            durationMillis = if (focused) TvMotion.FOCUS_IN_MS else TvMotion.FOCUS_OUT_MS,
            easing = TvMotion.EaseOut,
        )),
        label = "libraryViewModeScale",
    )

    Row(
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .height(44.dp)
            .focusRequester(requester)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .onPreviewKeyEvent { event ->
                val code = event.nativeKeyEvent.keyCode
                when {
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_LEFT -> onLeft()
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_RIGHT -> onRight()
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_DOWN -> onDown()
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_UP -> true
                    event.isTvActivationKey() -> {
                        if (event.type == KeyEventType.KeyUp) onToggle()
                        true
                    }
                    else -> false
                }
            }
            .background(
                color = if (selected) {
                    TvDesign.White
                } else if (focused) {
                    TvDesign.White.copy(alpha = .18f)
                } else {
                    TvDesign.SurfaceRaised.copy(alpha = .82f)
                },
                shape = ControlShape,
            )
            .border(
                width = if (focused) 1.dp else 0.dp,
                color = if (focused) TvDesign.White.copy(alpha = .42f) else Color.Transparent,
                shape = ControlShape,
            )
            .clickable(onClick = onToggle)
            .padding(horizontal = 13.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (label == null) LibraryModeGlyph(grid = gridView, focused = focused)
        Text(
            text = label ?: if (gridView) "Grid" else "List",
            color = if (selected) Color.Black else if (focused) TvDesign.White else TvDesign.Muted,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun LibraryModeGlyph(
    grid: Boolean,
    focused: Boolean,
) {
    val tint = if (focused) TvDesign.White else TvDesign.Muted
    if (grid) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            repeat(2) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    repeat(2) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .background(tint, RoundedCornerShape(1.dp)),
                        )
                    }
                }
            }
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(3) {
                Box(
                    modifier = Modifier
                        .width(13.dp)
                        .height(2.dp)
                        .background(tint, RoundedCornerShape(1.dp)),
                )
            }
        }
    }
}

@Composable
private fun LibraryPosterCard(
    media: MediaItem,
    historyCaption: String? = null,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onUpFromFirstRow: (() -> Unit)?,
    onLeftFromFirstColumn: (() -> Unit)?,
    blockRight: Boolean,
) {
    var focused by remember(media.id, media.type) { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) tvTunedFocusScale(1.02f) else 1f,
        animationSpec = tvTunedSpec(TvMotionGroup.FOCUS, focused, tween(
            durationMillis = if (focused) TvMotion.FOCUS_IN_MS else TvMotion.FOCUS_OUT_MS,
            easing = TvMotion.EaseOut,
        )),
        label = "libraryPosterScale",
    )

    Column(
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                shadowElevation = if (focused) 7.dp.toPx() else 0f
                shape = PosterShape
                clip = false
            }
            .focusRequester(requester)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .onPreviewKeyEvent { event ->
                val code = event.nativeKeyEvent.keyCode
                when {
                    event.type == KeyEventType.KeyDown &&
                        code == KeyEvent.KEYCODE_DPAD_UP &&
                        onUpFromFirstRow != null -> {
                        onUpFromFirstRow()
                        true
                    }

                    event.type == KeyEventType.KeyDown &&
                        code == KeyEvent.KEYCODE_DPAD_LEFT &&
                        onLeftFromFirstColumn != null -> {
                        onLeftFromFirstColumn()
                        true
                    }

                    event.type == KeyEventType.KeyDown &&
                        code == KeyEvent.KEYCODE_DPAD_RIGHT &&
                        blockRight -> true

                    else -> false
                }
            }
            .tvPosterActivation(
                onClick = onClick,
                onLongClick = onLongClick,
            )
            .clickable(onClick = onClick),
    ) {
        TvNetworkImage(
            url = media.poster,
            contentDescription = media.name,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(PosterShape)
                .border(
                    width = if (focused) 2.dp else 0.dp,
                    color = if (focused) TvDesign.White.copy(alpha = .88f) else Color.Transparent,
                    shape = PosterShape,
                ),
            contentScale = ContentScale.Crop,
        )

        Spacer(Modifier.height(7.dp))
        Text(
            text = media.name,
            color = TvDesign.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = historyCaption ?: listOfNotNull(
                media.releaseInfo,
                libraryTypeLabel(media),
            ).joinToString(" • "),
            color = TvDesign.Muted,
            fontSize = 9.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun LibraryListRow(
    media: MediaItem,
    historyCaption: String? = null,
    requester: FocusRequester,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onLeft: () -> Unit,
    onUpFromFirst: (() -> Unit)?,
) {
    var focused by remember(media.id, media.type) { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) tvTunedFocusScale(1.01f) else 1f,
        animationSpec = tvTunedSpec(TvMotionGroup.FOCUS, focused, tween(
            durationMillis = if (focused) TvMotion.FOCUS_IN_MS else TvMotion.FOCUS_OUT_MS,
            easing = TvMotion.EaseOut,
        )),
        label = "libraryListScale",
    )

    Row(
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .fillMaxWidth()
            .height(112.dp)
            .focusRequester(requester)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .onPreviewKeyEvent { event ->
                val code = event.nativeKeyEvent.keyCode
                when {
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_LEFT -> {
                        onLeft()
                        true
                    }
                    event.type == KeyEventType.KeyDown &&
                        code == KeyEvent.KEYCODE_DPAD_UP &&
                        onUpFromFirst != null -> {
                        onUpFromFirst()
                        true
                    }
                    event.type == KeyEventType.KeyDown && code == KeyEvent.KEYCODE_DPAD_RIGHT -> true
                    else -> false
                }
            }
            .tvPosterActivation(
                onClick = onClick,
                onLongClick = onLongClick,
            )
            .background(
                color = if (focused) {
                    TvDesign.White.copy(alpha = .11f)
                } else {
                    TvDesign.SurfaceRaised.copy(alpha = .46f)
                },
                shape = ListRowShape,
            )
            .border(
                width = if (focused) 1.dp else 0.dp,
                color = if (focused) TvDesign.White.copy(alpha = .34f) else Color.Transparent,
                shape = ListRowShape,
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TvNetworkImage(
            url = media.poster,
            contentDescription = media.name,
            modifier = Modifier
                .width(61.dp)
                .height(92.dp)
                .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop,
        )

        Spacer(Modifier.width(16.dp))
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = media.name,
                color = TvDesign.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = historyCaption ?: listOfNotNull(
                    media.releaseInfo,
                    libraryTypeLabel(media),
                ).joinToString(" • "),
                color = TvDesign.Muted,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Text(
            text = "›",
            color = if (focused) TvDesign.White else TvDesign.Muted,
            fontSize = 24.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(horizontal = 10.dp),
        )
    }
}

@Composable
private fun LibraryEmptyState(
    title: String,
    body: String,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(230.dp)
            .background(
                color = TvDesign.SurfaceRaised.copy(alpha = .58f),
                shape = EmptyShape,
            )
            .border(
                width = 1.dp,
                color = TvDesign.White.copy(alpha = .07f),
                shape = EmptyShape,
            )
            .padding(horizontal = 26.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = title,
            color = TvDesign.White,
            fontSize = 21.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = body,
            color = TvDesign.Muted,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            maxLines = 3,
        )
    }
}

private val ControlShape = RoundedCornerShape(999.dp)
private val PosterShape = RoundedCornerShape(12.dp)
private val ListRowShape = RoundedCornerShape(14.dp)
private val EmptyShape = RoundedCornerShape(18.dp)

private fun libraryMediaKey(media: MediaItem): String =
    "${media.type}:${media.id}"

private fun libraryTypeLabel(media: MediaItem): String =
    when (media.type.lowercase()) {
        "movie" -> "Movie"
        "series", "tv" -> "Series"
        "anime" -> "Anime"
        else -> media.type.replaceFirstChar { it.uppercase() }
    }

private fun androidx.compose.ui.input.key.KeyEvent.isTvActivationKey(): Boolean =
    nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
        nativeKeyEvent.keyCode == KeyEvent.KEYCODE_ENTER ||
        nativeKeyEvent.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER

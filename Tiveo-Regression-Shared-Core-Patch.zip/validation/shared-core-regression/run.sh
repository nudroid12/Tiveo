#!/usr/bin/env bash
# Run with an unpacked Gradle 9.3.1 distribution (bundles Kotlin compiler and Groovy JSON).
set -euo pipefail
gradle_dir="${1:?Usage: bash validation/shared-core-regression/run.sh /path/to/gradle-9.3.1}"
lib="$(cd "$gradle_dir/lib" && pwd)"
cd "$(dirname "$0")/../.."
p="shared/core/src/main/java/com/vueo/shared/core"
v="validation"
r="$v/shared-core-regression"
temp="$(mktemp -d)"
trap 'rm -rf "$temp"' EXIT
classpath=$(find "$lib" -maxdepth 1 -name '*.jar' -printf '%p:' | sed 's/:$//')
java -cp "$lib/*" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
  -no-stdlib -no-reflect -classpath "$classpath" -d "$temp/check.jar" \
  "$r"/*.kt "$v"/{AndroidFixture,StorageFixtures,MetadataFixture,TraktFixture,KidsFixture}.kt \
  "$p"/storage/{LibraryStore,LibraryEpisodeCache,PlaybackStore,ContinueWatchingPolicy,WatchedEpisodePolicy,TitleRating,LibraryHistoryPresentation,NewEpisodesPolicy,NewEpisodesPreferences}.kt \
  "$p"/media/{MediaModels,MediaTypePolicy,AddonStreamHints,EpisodeNumberPolicy}.kt \
  "$p"/stremio/StremioUrls.kt "$p"/extensions/StremioEpisodeParser.kt "$p"/sync/SyncLocalAdapter.kt
java -cp "$temp/check.jar:$lib/*" com.vueo.shared.core.sync.SharedCoreRegressionCheckKt

package org.json
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
private fun unwrap(value:Any?):Any? = when(value) {
    is JSONObject -> value.data
    is JSONArray -> value.data
    else -> value
}
class JSONObject(internal val data:MutableMap<String,Any?> = linkedMapOf()) {
    @Suppress("UNCHECKED_CAST")
    constructor(raw:String?):this((JsonSlurper().parseText(raw ?: "{}") as Map<String,Any?>).toMutableMap())
    fun get(key:String):Any = data.getValue(key) ?: error("null")
    fun has(key:String) = data.containsKey(key)
    fun isNull(key:String) = data[key] == null
    fun optInt(key:String,default:Int=0) = (data[key] as? Number)?.toInt() ?: default
    fun optDouble(key:String,default:Double=Double.NaN) = (data[key] as? Number)?.toDouble() ?: default
    fun getBoolean(key:String)=get(key) as Boolean
    fun getLong(key:String)=(get(key) as Number).toLong()
    fun getJSONArray(key:String)=optJSONArray(key) ?: error("missing array")
    fun getInt(key:String) = (get(key) as Number).toInt()
    fun getString(key:String) = get(key).toString()
    fun remove(key:String) = data.remove(key)
    fun keys() = data.keys.iterator()
    @Suppress("UNCHECKED_CAST")
    fun optJSONObject(key:String) = (data[key] as? Map<String,Any?>)?.let { JSONObject(it.toMutableMap()) }
    fun getJSONObject(key:String) = optJSONObject(key) ?: error("not object: $key")
    fun put(key:String,value:Any?):JSONObject = apply { data[key]=unwrap(value) }
    fun optString(key:String, default:String="") = data[key]?.toString() ?: default
    fun optBoolean(key:String,default:Boolean=false) = data[key] as? Boolean ?: default
    fun optLong(key:String,default:Long=0L) = (data[key] as? Number)?.toLong() ?: default
    fun optJSONArray(key:String) = (data[key] as? List<*>)?.let { JSONArray(it) }
    override fun toString():String = JsonOutput.toJson(data)
}
class JSONArray(items:Collection<*> = emptyList<Any?>()) {
    internal val data:MutableList<Any?> = items.map(::unwrap).toMutableList()
    constructor(raw:String?):this(JsonSlurper().parseText(raw ?: "[]") as List<*>)
    fun put(value:Any?):JSONArray = apply { data.add(unwrap(value)) }
    fun length()=data.size
    @Suppress("UNCHECKED_CAST")
    fun optJSONObject(index:Int) = (data.getOrNull(index) as? Map<String,Any?>)?.let { JSONObject(it.toMutableMap()) }
    fun getJSONObject(index:Int) = optJSONObject(index) ?: error("not object")
    fun getString(index:Int)=data[index].toString()
    fun optString(index:Int) = data.getOrNull(index)?.toString() ?: ""
    override fun toString():String = JsonOutput.toJson(data)
}

package com.vueo.shared.core.sync

import android.content.Context
import com.vueo.shared.core.extensions.toEpisodeList
import com.vueo.shared.core.storage.*
import com.vueo.shared.core.media.*
import org.json.JSONArray
import org.json.JSONObject

fun main() {
    fun verify(label:String, valid:Boolean) { check(valid){label}; println("PASS $label") }
    val parsed=JSONArray("""[{"id":"tt123:1:1","season":0,"episode":1},{"id":"tt123:0:2"},{"id":"tt123:2:1"},{"id":"123:4"}]""").toEpisodeList()
    verify("raw addon parser preserves explicit and inferred Specials",parsed.map{it.season to it.episode}==listOf(0 to 1,0 to 2,2 to 1))
    val sender=Context()
    val show=MediaItem("tt123","series","Specials",episodes=parsed)
    val src=LibraryStore(sender)
    sender.activeProfile="second"
    val ep=parsed.first()
    src.recordPlayback(show,ep.id,ep.title,ep.season,ep.episode,120_000,120_000,PlaybackUpdateClock.next())
    val prefs=sender.getSharedPreferences("vueo_library",0)
    prefs.edit().remove("profile:second:watched_episodes_v1").apply()
    val source=SyncLocalAdapter(sender)
    val records=source.snapshot(setOf("history"))
    val history=records.values.first{JSONArray(it.getString("key")).getString(2)=="history"}
    val marker=records.values.first{JSONArray(it.getString("key")).getString(2)=="watched_episodes_v1"}
    verify("snapshot migrates old completed history before sync", records.size==2)
    val receiver=Context()
    val adapter=SyncLocalAdapter(receiver)
    val dest=LibraryStore(receiver,profileIdOverride="second",publishTraktChanges=false,filterForKids=false)
    val default=LibraryStore(receiver)
    val key=WatchedEpisodePolicy.key(show,ep.season,ep.episode)
    fun apply(vararg rows:JSONObject) {
        val before=adapter.snapshot(setOf("history")).mapValues{syncFingerprint(it.value.optJSONObject("value"))}
        adapter.apply(rows.toList(),before)
    }
    apply(history)
    verify("legacy remote completed episode creates durable watched member",key in dest.watchedEpisodeKeys())
    verify("remote history respects destination profile",default.watchedEpisodeKeys().isEmpty())
    val tomb=JSONObject().put("kind","history").put("key",marker.getString("key")).put("deleted",true)
    fun historyAt(stamp:Long):JSONObject {
        val row=JSONObject(history.toString())
        val value=row.getJSONObject("value")
        value.put("entry",value.getJSONObject("entry").put("lastWatchedEpochMs",stamp))
        return row.put("value",value)
    }
    apply(tomb,historyAt(PlaybackUpdateClock.next()))
    verify("explicit remote unwatch wins over legacy history",key !in dest.watchedEpisodeKeys())
    val rp=receiver.getSharedPreferences("vueo_library",0)
    val raw="profile:second:episode_watch_reset:$key"
    val stamp=rp.getLong(raw,0L)
    apply(tomb)
    verify("repeated remote tombstone does not advance cutoff",stamp>0 && rp.getLong(raw,0L)==stamp)
    apply(historyAt(stamp-1))
    verify("delayed old history does not restore unwatched status",key !in dest.watchedEpisodeKeys())
    apply(historyAt(stamp+1))
    verify("new completed history after cutoff can mark watched again",key in dest.watchedEpisodeKeys())
    apply(tomb)
    apply(marker)
    verify("explicit remote watched membership can restore status",key in dest.watchedEpisodeKeys())
    val historyTomb=JSONObject().put("kind","history").put("key",history.getString("key")).put("deleted",true)
    apply(historyTomb)
    verify("ordinary history pruning does not erase durable watched member",key in dest.watchedEpisodeKeys())
    verify("recent searches and library filters are not synced",adapter.preferenceCategories("vueo_library","recent_searches_v1").isEmpty() && adapter.preferenceCategories("vueo_library","library_filter").isEmpty())
}

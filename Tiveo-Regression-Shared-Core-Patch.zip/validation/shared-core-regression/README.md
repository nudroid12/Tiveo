# Shared Core regression check

Run from repository root with `bash validation/shared-core-regression/run.sh /path/to/gradle-9.3.1`.

This isolated JVM check exercises the production Stremio episode parser, LibraryStore,
and SyncLocalAdapter using in-memory Android preferences, Groovy-backed JSON, and
offline service fixtures. No account credentials, network calls, or Android emulator
are required. Fixtures are not packaged into the APK. The fingerprint fixture mirrors
the production SHA-256 algorithm; this is not an end-to-end Supabase test.

The normal APK workflow also executes the existing shared-core Debug unit test task.

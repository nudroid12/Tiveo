package com.vueo.shared.core.sync
import org.json.JSONObject
import java.security.MessageDigest
object VueoSyncConfig { val categories=listOf("profiles","favorites","history","progress","addons","integrations","trakt").associateWith{it} }
internal fun syncFingerprint(value: JSONObject?): String? = value?.let {
    MessageDigest.getInstance("SHA-256").digest(it.toString().toByteArray(Charsets.UTF_8)).joinToString("") { byte -> "%02x".format(byte) }
}


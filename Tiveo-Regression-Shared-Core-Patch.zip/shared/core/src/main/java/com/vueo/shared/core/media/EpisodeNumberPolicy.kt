package com.vueo.shared.core.media

/** One season/episode identity rule for addon metadata and Details hydration. */
object EpisodeNumberPolicy {
    data class Numbers(val season: Int, val episode: Int)

    fun normalize(id: String, rawSeason: Int, rawEpisode: Int): Numbers {
        val parts = id.split(":")
        // Numeric components alone are not enough; an episode ID must contain
        // an identity prefix followed by both season and episode coordinates.
        val hasCoordinates = parts.size >= 3 && parts.dropLast(2).joinToString(":").isNotBlank()
        val idSeason = if (hasCoordinates) parts[parts.lastIndex - 1].toIntOrNull() else null
        val idEpisode = if (hasCoordinates) parts.last().toIntOrNull() else null
        return Numbers(
            season = when {
                rawSeason >= 0 -> rawSeason
                idSeason != null && idSeason >= 0 -> idSeason
                else -> rawSeason
            },
            episode = when {
                rawEpisode > 0 -> rawEpisode
                idEpisode != null && idEpisode > 0 -> idEpisode
                else -> rawEpisode
            },
        )
    }
}

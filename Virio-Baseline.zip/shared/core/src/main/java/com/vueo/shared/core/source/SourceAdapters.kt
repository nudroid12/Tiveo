package com.vueo.shared.core.source

import com.vueo.shared.core.media.StreamSource

fun StreamSource.toSourceCandidate(): SourceCandidate =
    SourceCandidate(
        id = buildString {
            append(providerId)
            append(':')
            append(url ?: infoHash ?: name)
            fileIndex?.let {
                append(':')
                append(it)
            }
        },
        name = name,
        url = url,
        infoHash = infoHash,
        fileIndex = fileIndex,
        quality = quality,
        codec = codec,
        hdr = hdr,
        audio = audio,
        language = language,
        sizeBytes = sizeBytes,
        headers = headers,
        rankBoost = rankBoost,
        providerId = providerId,
        providerName = providerName,
        serverName = serverName,
        mimeType = mimeType,
        subtitles = subtitles,
        addonHints = addonHints,
    )

fun SourceCandidate.toStreamSource(): StreamSource =
    StreamSource(
        name = name,
        url = url,
        infoHash = infoHash,
        fileIndex = fileIndex,
        quality = quality,
        codec = codec,
        hdr = hdr,
        audio = audio,
        language = language,
        sizeBytes = sizeBytes,
        headers = headers,
        rankBoost = rankBoost,
        providerId = providerId,
        providerName = providerName,
        serverName = serverName,
        mimeType = mimeType,
        subtitles = subtitles,
        addonHints = addonHints,
    )

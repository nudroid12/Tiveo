package com.vueo.shared.core.plugin

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

class PluginStore(context: Context) {
    private val appContext = context.applicationContext
    private val codeStore = ProviderCodeStore(appContext)

    private val prefs = appContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE,
    )

    @Volatile
    private var cachedRepositoriesRaw: String? = null

    @Volatile
    private var cachedRepositories: List<PluginRepositoryDescriptor> = emptyList()

    fun pluginsEnabled(): Boolean =
        prefs.getBoolean(KEY_PLUGINS_ENABLED, true)

    fun setPluginsEnabled(enabled: Boolean) {
        prefs.edit()
            .putBoolean(KEY_PLUGINS_ENABLED, enabled)
            .apply()
        PluginRuntimeCache.clear()
    }

    fun isRepositoryEnabled(
        repository: PluginRepositoryDescriptor,
    ): Boolean =
        prefs.getBoolean(
            repositoryEnabledKey(
                repository.manifestUrl
            ),
            true,
        )

    fun setRepositoryEnabled(
        repository: PluginRepositoryDescriptor,
        enabled: Boolean,
    ) {
        prefs.edit()
            .putBoolean(
                repositoryEnabledKey(
                    repository.manifestUrl
                ),
                enabled,
            )
            .apply()
        PluginRuntimeCache.clear()
    }

    fun tmdbApiKey(): String =
        prefs.getString(KEY_TMDB_API_KEY, "")
            .orEmpty()
            .trim()

    fun setTmdbApiKey(apiKey: String) {
        prefs.edit()
            .putString(KEY_TMDB_API_KEY, apiKey.trim())
            .apply()
    }

    suspend fun seedDevelopmentDefaultsIfNeeded() {
        defaultSeedMutex.withLock {
            if (prefs.getInt(KEY_DEV_DEFAULTS_REVISION, 0) < DEV_DEFAULTS_REVISION) {
                repositories().filter { it.manifestUrl in RETIRED_DEFAULT_MANIFESTS }
                    .forEach { remove(it.manifestUrl) }
                prefs.edit().putInt(KEY_DEV_DEFAULTS_REVISION, DEV_DEFAULTS_REVISION).apply()
            }

            for (url in DEVELOPMENT_DEFAULT_MANIFESTS) {
                val seedKey = "tiveo_default_installed:$url"
                if (prefs.getBoolean(seedKey, false)) continue

                if (repositories().none { sameDefaultManifest(it.manifestUrl, url) }) {
                    val repository = try {
                        PluginRepositoryClient.fetch(url)
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (error: Exception) {
                        Log.w("PluginStore", "Default plugin manifest unavailable: $url", error)
                        continue
                    }

                    synchronized(repositoryWriteLock) {
                        val installed = repositories()
                        if (installed.none { sameDefaultManifest(it.manifestUrl, url) }) {
                            saveRepositories(installed + repository)
                            PluginRuntimeCache.clear()
                        }
                    }
                }

                // Remember each successful seed so a user can remove it later.
                prefs.edit().putBoolean(seedKey, true).apply()
            }
        }
    }

    fun isDevelopmentDefault(manifestUrl: String): Boolean =
        DEVELOPMENT_DEFAULT_MANIFESTS.any { sameDefaultManifest(manifestUrl, it) }

    private fun sameDefaultManifest(first: String, second: String): Boolean =
        first.trim().removeSuffix("/").replace("/refs/heads/", "/")
            .equals(second.replace("/refs/heads/", "/"), ignoreCase = true)

    @Synchronized
    fun repositories(): List<PluginRepositoryDescriptor> {
        val raw = prefs.getString(
            KEY_REPOSITORIES_JSON,
            null,
        ) ?: run {
            cachedRepositoriesRaw = null
            cachedRepositories = emptyList()
            return emptyList()
        }

        if (raw == cachedRepositoriesRaw) {
            return cachedRepositories
        }

        val parsed = runCatching {
            val array = JSONArray(raw)

            (0 until array.length())
                .mapNotNull { index ->
                    array.optJSONObject(index)
                        ?.toRepository()
                }
        }.getOrDefault(emptyList())

        cachedRepositoriesRaw = raw
        cachedRepositories = parsed
        return parsed
    }

    fun upsert(repository: PluginRepositoryDescriptor) {
        synchronized(repositoryWriteLock) {
            val next = repositories().filterNot { it.manifestUrl == repository.manifestUrl }
            saveRepositories(next + repository)
            PluginRuntimeCache.clear()
        }
    }

    fun remove(manifestUrl: String) {
        synchronized(repositoryWriteLock) {
            saveRepositories(repositories().filterNot { it.manifestUrl == manifestUrl })
            prefs.edit().remove(repositoryEnabledKey(manifestUrl)).apply()
            codeStore.removeRepository(manifestUrl)
            PluginRuntimeCache.clear()
        }
    }

    fun isProviderEnabled(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
    ): Boolean {
        val key = providerKey(repository, provider)

        return if (prefs.contains(key)) {
            prefs.getBoolean(
                key,
                provider.defaultEnabled,
            )
        } else {
            provider.defaultEnabled
        }
    }

    fun setProviderEnabled(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
        enabled: Boolean,
    ) {
        prefs.edit()
            .putBoolean(
                providerKey(repository, provider),
                enabled,
            )
            .apply()
        PluginRuntimeCache.clear()
    }

    fun totalProviderCount(): Int =
        repositories().sumOf { it.providers.size }

    fun enabledProviderCount(): Int =
        repositories()
            .filter(::isRepositoryEnabled)
            .sumOf { repository ->
                repository.providers.count { provider ->
                    isProviderEnabled(
                        repository,
                        provider,
                    )
                }
            }

    @Synchronized
    private fun saveRepositories(
        repositories: List<PluginRepositoryDescriptor>,
    ) {
        val array = JSONArray()

        repositories.forEach { repository ->
            array.put(repository.toJson())
        }

        val raw = array.toString()
        prefs.edit()
            .putString(
                KEY_REPOSITORIES_JSON,
                raw,
            )
            .apply()
        cachedRepositoriesRaw = raw
        cachedRepositories = repositories.toList()
    }

    private fun repositoryEnabledKey(
        manifestUrl: String,
    ): String =
        "repository_enabled:$manifestUrl"

    private fun providerKey(
        repository: PluginRepositoryDescriptor,
        provider: PluginProviderDescriptor,
    ): String =
        "provider:${repository.manifestUrl}:${provider.id}"

    companion object {
        private const val PREFS_NAME = "vueo_plugins"
        private const val KEY_PLUGINS_ENABLED = "plugins_enabled"
        private const val KEY_REPOSITORIES_JSON = "repositories_json"
        private const val KEY_TMDB_API_KEY = "tmdb_api_key"
        private const val KEY_DEV_DEFAULTS_REVISION =
            "plugin_dev_defaults_revision"

        private const val DEV_DEFAULTS_REVISION = 2

        private val defaultSeedMutex = Mutex()
        private val repositoryWriteLock = Any()

        val DEVELOPMENT_DEFAULT_MANIFESTS: Set<String> = setOf(
            "https://raw.githubusercontent.com/Luckez12/CloudAnime/main/manifest.json",
            "https://raw.githubusercontent.com/Luckez12/Cloudbank/refs/heads/main/manifest.json",
        )

        private val RETIRED_DEFAULT_MANIFESTS = setOf(
            "https://raw.githubusercontent.com/yoruix/nuvio-providers/refs/heads/main/manifest.json",
            "https://raw.githubusercontent.com/D3adlyRocket/All-in-One-Nuvio/refs/heads/main/manifest.json",
        )
    }
}

private fun PluginRepositoryDescriptor.toJson(): JSONObject =
    JSONObject().apply {
        put("manifestUrl", manifestUrl)
        put("baseUrl", baseUrl)
        put("name", name)
        put("version", version)
        put("description", description)

        put(
            "providers",
            JSONArray().apply {
                providers.forEach {
                    put(it.toJson())
                }
            }
        )
    }

private fun PluginProviderDescriptor.toJson(): JSONObject =
    JSONObject().apply {
        put("id", id)
        put("name", name)
        put("description", description)
        put("version", version)
        put("author", author)
        put(
            "supportedTypes",
            JSONArray(supportedTypes.toList()),
        )
        put("filename", filename)
        put("defaultEnabled", defaultEnabled)
        put("logo", logo)
        put(
            "contentLanguages",
            JSONArray(contentLanguages),
        )
        put("formats", JSONArray(formats))
        put("limited", limited)
        put(
            "disabledPlatforms",
            JSONArray(disabledPlatforms.toList()),
        )
        put(
            "supportsExternalPlayer",
            supportsExternalPlayer,
        )
        put("runtimeTimeoutMs", runtimeTimeoutMs)
    }

private fun JSONObject.toRepository():
    PluginRepositoryDescriptor? {

    val manifestUrl = optString("manifestUrl")
        .takeIf { it.isNotBlank() }
        ?: return null

    val baseUrl = optString("baseUrl")
        .takeIf { it.isNotBlank() }
        ?: return null

    val name = optString("name")
        .takeIf { it.isNotBlank() }
        ?: return null

    val array = optJSONArray("providers")
        ?: JSONArray()

    return PluginRepositoryDescriptor(
        manifestUrl = manifestUrl,
        baseUrl = baseUrl,
        name = name,
        version = optString(
            "version",
            "0.0.0",
        ),
        description = optString("description")
            .takeIf { it.isNotBlank() },
        providers = (0 until array.length())
            .mapNotNull { index ->
                array.optJSONObject(index)
                    ?.toStoredProvider()
            },
    )
}

private fun JSONObject.toStoredProvider():
    PluginProviderDescriptor? {

    val id = optString("id")
        .takeIf { it.isNotBlank() }
        ?: return null

    val name = optString("name")
        .takeIf { it.isNotBlank() }
        ?: return null

    val filename = optString("filename")
        .takeIf { it.isNotBlank() }
        ?: return null

    return PluginProviderDescriptor(
        id = id,
        name = name,
        description = optString("description")
            .takeIf { it.isNotBlank() },
        version = optString(
            "version",
            "0.0.0",
        ),
        author = optString("author")
            .takeIf { it.isNotBlank() },
        supportedTypes =
            optJSONArray("supportedTypes")
                .toStringList()
                .map { it.lowercase() }
                .toSet(),
        filename = filename,
        defaultEnabled =
            optBoolean("defaultEnabled", true),
        logo = optString("logo")
            .takeIf { it.isNotBlank() },
        contentLanguages =
            optJSONArray("contentLanguages")
                .toStringList(),
        formats =
            optJSONArray("formats")
                .toStringList(),
        limited = optBoolean(
            "limited",
            false,
        ),
        disabledPlatforms =
            optJSONArray("disabledPlatforms")
                .toStringList()
                .map { it.lowercase() }
                .toSet(),
        supportsExternalPlayer =
            optBoolean(
                "supportsExternalPlayer",
                true,
            ),
        runtimeTimeoutMs =
            optLong(
                "runtimeTimeoutMs",
                10_000L,
            ).coerceIn(3_000L, 20_000L),
    )
}

private fun JSONArray?.toStringList():
    List<String> {

    if (this == null) {
        return emptyList()
    }

    return (0 until length())
        .mapNotNull {
            optString(it)
                .takeIf(String::isNotBlank)
        }
}

private fun JSONArray?.toStringSet():
    Set<String> =
    toStringList().toSet()

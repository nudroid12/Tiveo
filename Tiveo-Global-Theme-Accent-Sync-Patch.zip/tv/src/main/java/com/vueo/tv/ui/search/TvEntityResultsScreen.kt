package com.vueo.tv.search

import com.vueo.shared.core.search.SearchPolicy
import com.vueo.tv.ui.TvPosterGridReveal
import com.vueo.tv.ui.motion.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vueo.shared.core.media.MediaItem
import com.vueo.shared.core.search.EntityResultOrder
import com.vueo.shared.core.search.MediaEntityKind
import com.vueo.shared.core.search.MediaEntityTarget
import com.vueo.shared.core.search.EntityResultsPipeline
import com.vueo.shared.core.diagnostics.PerformanceDiagnostics
import kotlinx.coroutines.flow.collect
import com.vueo.shared.core.search.SearchOrchestrator
import com.vueo.tv.core.TvRuntime
import com.vueo.tv.ui.TvDesign
import com.vueo.tv.ui.TvNetworkImage
import kotlinx.coroutines.delay

private const val ENTITY_COLUMNS = 6

@Composable
internal fun TvEntityResultsScreen(
    runtime: TvRuntime,
    target: MediaEntityTarget,
    active: Boolean = true,
    onBack: () -> Unit,
    onOpenMedia: (MediaItem) -> Unit,
) {
    BackHandler(enabled = active, onBack = onBack)

    val entityEngine = runtime.engine
    val tmdbApiKey = runtime.pluginStore.tmdbApiKey()
    val requestKey = remember(entityEngine, target, tmdbApiKey) { Any() }
    val latestRequestKey by androidx.compose.runtime.rememberUpdatedState(requestKey)
    var retryGeneration by remember(requestKey) { mutableStateOf(0) }
    val loadKey = remember(requestKey, retryGeneration) { Any() }
    val latestLoadKey by androidx.compose.runtime.rememberUpdatedState(loadKey)
    var results by remember(requestKey) { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loading by remember(requestKey) { mutableStateOf(true) }
    var loadFailed by remember(requestKey) { mutableStateOf(false) }
    var preparationFailed by remember(requestKey) { mutableStateOf(false) }
    var resultOrder by remember(target) { mutableStateOf(EntityResultOrder.NEWEST) }
    // Keep the current grid during same-target updates, including sort changes.
    var orderedResults by remember(requestKey) { mutableStateOf<List<MediaItem>>(emptyList()) }
    val sortKey = remember(loadKey, results, resultOrder) { Any() }
    val latestSortKey by androidx.compose.runtime.rememberUpdatedState(sortKey)
    var preparedSortKey by remember(requestKey) { mutableStateOf<Any?>(null) }
    val preparing = preparedSortKey !== sortKey
    val busy = loading || preparing
    val failed = loadFailed || preparationFailed
    val gridState = rememberLazyGridState()
    var gridHasFocus by remember(requestKey) { mutableStateOf(false) }
    var publishedOrder by remember(requestKey) { mutableStateOf(resultOrder) }
    var focusedMediaKey by remember(target) { mutableStateOf<String?>(null) }


    LaunchedEffect(loadKey) {
        loading = true
        loadFailed = false
        results = emptyList()
        try {
            EntityResultsPipeline.batches { publish ->
                PerformanceDiagnostics.measureWork("tv_entity_load", PerformanceDiagnostics.Tab.DETAILS) {
                    SearchOrchestrator.entityResults(
                        engine = entityEngine,
                        target = target,
                        tmdbApiKey = tmdbApiKey,
                        onPartial = publish,
                    )
                }
            }.collect { batch ->
                if (latestRequestKey === requestKey && latestLoadKey === loadKey) {
                    results = batch.items
                    loading = !batch.complete
                    loadFailed = batch.failureClass != null
                    if (batch.failureClass != null) {
                        PerformanceDiagnostics.captureRuntimeEvent(
                            "ENTITY_RESULTS platform=tv event=load_failed error=${batch.failureClass}",
                        )
                    }
                }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            if (latestRequestKey === requestKey && latestLoadKey === loadKey) {
                loadFailed = true
                PerformanceDiagnostics.captureRuntimeEvent(
                    "ENTITY_RESULTS platform=tv event=load_failed error=${error.javaClass.simpleName}",
                )
            }
        } finally {
            if (latestRequestKey === requestKey && latestLoadKey === loadKey) loading = false
        }
    }

    LaunchedEffect(sortKey, gridHasFocus) {
        // Keep the currently browsed catalog stable while posters have focus.
        // New batches remain in results and are prepared after leaving the grid.
        if (gridHasFocus) return@LaunchedEffect
        val inputResults = results
        val inputOrder = resultOrder
        preparationFailed = false
        try {
            val prepared = EntityResultsPipeline.prepare {
                PerformanceDiagnostics.measureWork("tv_entity_prepare", PerformanceDiagnostics.Tab.DETAILS) {
                    SearchOrchestrator.orderEntityResults(inputResults, inputOrder)
                }
            }
            if (latestRequestKey === requestKey && latestSortKey === sortKey) {
                val orderChanged = publishedOrder != inputOrder
                // Publish the list and its viewport reset in the same UI turn.
                // requestScrollToItem overrides lazy-grid key anchoring on the
                // next remeasure, unlike an earlier scroll of the OLD list.
                orderedResults = prepared
                if (orderChanged) {
                    gridState.requestScrollToItem(0)
                    focusedMediaKey = null
                }
                publishedOrder = inputOrder
                withFrameNanos { }
                PerformanceDiagnostics.captureRuntimeEvent(
                    "ENTITY_RESULTS platform=tv event=sort_published order=$inputOrder count=${prepared.size} reset=$orderChanged",
                )
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            if (latestSortKey === sortKey) {
                preparationFailed = true
                PerformanceDiagnostics.captureRuntimeEvent(
                    "ENTITY_RESULTS platform=tv event=prepare_failed error=${error.javaClass.simpleName}",
                )
            }
        } finally {
            if (latestRequestKey === requestKey && latestSortKey === sortKey) preparedSortKey = sortKey
        }
    }
    val newestRequester = remember(target) { FocusRequester() }
    val popularRequester = remember(target) { FocusRequester() }
    val selectedOrderRequester =
        if (resultOrder == EntityResultOrder.NEWEST) newestRequester else popularRequester
    val resultKeys = remember(orderedResults) {
        orderedResults.map { "${it.type}:${it.id}" }
    }
    val requesterPool = remember(requestKey) { mutableMapOf<String, FocusRequester>() }
    val requesters = remember(requestKey, resultKeys) {
        requesterPool.keys.retainAll(resultKeys.toSet())
        resultKeys.associateWith { key -> requesterPool.getOrPut(key) { FocusRequester() } }
    }
    val firstRequester = resultKeys.firstOrNull()?.let(requesters::get) ?: FocusRequester.Cancel
    var newestFocused by remember(target) { mutableStateOf(false) }
    var popularFocused by remember(target) { mutableStateOf(false) }
    val latestFocusedMediaKey by androidx.compose.runtime.rememberUpdatedState(focusedMediaKey)
    var enterGridPending by remember(requestKey) { mutableStateOf(false) }
    val latestActive by androidx.compose.runtime.rememberUpdatedState(active)
    LaunchedEffect(active, enterGridPending, preparing, resultKeys, resultOrder) {
        if (!active || !enterGridPending || preparing || resultKeys.isEmpty()) return@LaunchedEffect
        // Focus the published viewport; Down must not reset catalog position.
        withFrameNanos { }
        val entryIndex = gridState.firstVisibleItemIndex.coerceIn(0, resultKeys.lastIndex)
        val entryRequester = requesters[resultKeys[entryIndex]] ?: return@LaunchedEffect
        repeat(6) {
            withFrameNanos { }
            if (!latestActive || (!newestFocused && !popularFocused)) {
                enterGridPending = false
                return@LaunchedEffect
            }
            if (runCatching { entryRequester.requestFocus() }.getOrDefault(false)) {
                enterGridPending = false
                return@LaunchedEffect
            }
        }
        enterGridPending = false
        PerformanceDiagnostics.captureRuntimeEvent(
            "ENTITY_RESULTS platform=tv event=grid_focus_failed order=$resultOrder count=${resultKeys.size}",
        )
    }


    LaunchedEffect(active, resultKeys, busy, newestFocused, popularFocused, enterGridPending, gridHasFocus) {
        if (!active || gridHasFocus || busy || enterGridPending || newestFocused || popularFocused || resultKeys.isEmpty()) return@LaunchedEffect
        val restoreIndex = latestFocusedMediaKey?.let(resultKeys::indexOf)?.takeIf { it >= 0 } ?: 0
        if (gridState.layoutInfo.visibleItemsInfo.none { it.index == restoreIndex }) {
            gridState.scrollToItem(restoreIndex)
        }
        delay(90)
        val focusedKey = latestFocusedMediaKey
        val restored = focusedKey?.let { key ->
            requesters[key]?.let { requester ->
                runCatching { requester.requestFocus() }.getOrDefault(false)
            }
        } == true
        if (!restored) {
            runCatching { firstRequester.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TvDesign.Black),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 60.dp, end = 60.dp, top = 24.dp, bottom = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = target.name,
                    color = TvDesign.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = when {
                        busy -> "Loading…"
                        else -> "${orderedResults.size} titles · " + when (target.kind) {
                            MediaEntityKind.ACTOR -> "Cast titles"
                            MediaEntityKind.COMPANY -> "Production titles"
                            MediaEntityKind.NETWORK -> "Network titles"
                        }
                    },
                    color = TvDesign.Muted,
                    fontSize = 12.sp,
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TvEntitySortTab(
                    label = "Newest",
                    selected = resultOrder == EntityResultOrder.NEWEST,
                    requester = newestRequester,
                    leftRequester = FocusRequester.Cancel,
                    rightRequester = popularRequester,
                    downRequester = firstRequester,
                    onDown = { enterGridPending = true },
                    onFocusChanged = {
                        newestFocused = it
                        if (it) {
                            enterGridPending = false
                            resultOrder = EntityResultOrder.NEWEST
                        }
                    },
                    onClick = { resultOrder = EntityResultOrder.NEWEST },
                )
                TvEntitySortTab(
                    label = "Popular",
                    selected = resultOrder == EntityResultOrder.POPULAR,
                    requester = popularRequester,
                    leftRequester = newestRequester,
                    rightRequester = FocusRequester.Cancel,
                    downRequester = firstRequester,
                    onDown = { enterGridPending = true },
                    onFocusChanged = {
                        popularFocused = it
                        if (it) {
                            enterGridPending = false
                            resultOrder = EntityResultOrder.POPULAR
                        }
                    },
                    onClick = { resultOrder = EntityResultOrder.POPULAR },
                )
            }
        }

        if (failed) {
            androidx.compose.material3.TextButton(
                onClick = { retryGeneration++ },
                modifier = Modifier.padding(horizontal = 60.dp),
            ) {
                Text("Couldn't load all titles. Retry", color = TvDesign.White)
            }
        }

        when {
            orderedResults.isNotEmpty() -> {
                TvPosterGridReveal {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(ENTITY_COLUMNS),
                        state = gridState,
                        modifier = Modifier.fillMaxSize()
                            .onFocusChanged { gridHasFocus = it.hasFocus }
                            .focusGroup(),
                        contentPadding = PaddingValues(
                            start = 60.dp,
                            end = 60.dp,
                            top = 4.dp,
                            bottom = 36.dp,
                        ),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        itemsIndexed(
                            items = orderedResults,
                            key = { _, item -> "${target.kind}:${item.type}:${item.id}" },
                        ) { index, item ->
                            val mediaKey = "${item.type}:${item.id}"
                            TvEntityPosterTile(
                                item = item,
                                requester = requesters.getValue(mediaKey),
                                upRequester = if (index < ENTITY_COLUMNS) {
                                    selectedOrderRequester
                                } else {
                                    null
                                },
                                blockLeft = index % ENTITY_COLUMNS == 0,
                                blockRight = index % ENTITY_COLUMNS == ENTITY_COLUMNS - 1 ||
                                    index == orderedResults.lastIndex,
                                onFocused = { focusedMediaKey = mediaKey },
                                onClick = {
                                    focusedMediaKey = mediaKey
                                    onOpenMedia(item)
                                },
                            )
                        }
                    }
                }
            }

            busy -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        color = TvDesign.Accent,
                        strokeWidth = 2.dp,
                    )
                }
            }

            else -> {
                Box(
                    modifier = Modifier.fillMaxSize().padding(48.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = if (failed) "Go back or retry to load titles." else when (target.kind) {
                            MediaEntityKind.ACTOR -> "No titles found for this cast member."
                            MediaEntityKind.COMPANY -> "No titles found for this production company."
                            MediaEntityKind.NETWORK -> "No titles found for this network."
                        },
                        color = TvDesign.Muted,
                        fontSize = 15.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun TvEntitySortTab(
    label: String,
    selected: Boolean,
    requester: FocusRequester,
    leftRequester: FocusRequester,
    rightRequester: FocusRequester,
    downRequester: FocusRequester,
    onDown: () -> Unit,
    onClick: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
) {
    var focused by remember(label) { mutableStateOf(false) }
    val shape = RoundedCornerShape(9.dp)

    Box(
        modifier = Modifier
            .focusRequester(requester)
            .focusProperties {
                left = leftRequester
                right = rightRequester
                down = downRequester
            }
            .onPreviewKeyEvent { event ->
                if (event.key == Key.DirectionDown) {
                    if (event.type == KeyEventType.KeyDown) onDown()
                    true
                } else false
            }
            .onFocusChanged {
                focused = it.isFocused
                onFocusChanged(it.isFocused)
            }
            .background(
                when {
                    selected -> TvDesign.Accent
                    focused -> TvDesign.SurfaceRaised
                    else -> Color.White.copy(alpha = .04f)
                },
                shape,
            )
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = when {
                    focused -> TvDesign.Focus
                    selected -> TvDesign.Accent.copy(alpha = .26f)
                    else -> Color.White.copy(alpha = .08f)
                },
                shape = shape,
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) TvDesign.OnAccent else TvDesign.White,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
private fun TvEntityPosterTile(
    item: MediaItem,
    requester: FocusRequester,
    upRequester: FocusRequester? = null,
    blockLeft: Boolean,
    blockRight: Boolean,
    onFocused: () -> Unit,
    onClick: () -> Unit,
) {
    var focused by remember(item.id, item.type) { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .focusRequester(requester)
            .focusProperties {
                if (blockLeft) left = FocusRequester.Cancel
                if (blockRight) right = FocusRequester.Cancel
                if (upRequester != null) {
                    up = upRequester
                }
            }
            .onFocusChanged { state ->
                focused = state.isFocused
                if (state.isFocused) onFocused()
            }
            .clickable(onClick = onClick),
    ) {
        TvNetworkImage(
            url = item.poster,
            contentDescription = item.name,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .border(
                    width = if (focused) 2.dp else 0.dp,
                    color = if (focused) TvDesign.Focus else Color.Transparent,
                    shape = RoundedCornerShape(10.dp),
                ),
            contentScale = ContentScale.Crop,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = item.name,
            color = TvDesign.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = SearchPolicy.releaseYear(item).takeIf { it > 0 }?.toString()
                ?: item.releaseInfo.orEmpty(),
            color = TvDesign.Muted,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

package com.vueo.mobile.ui

import kotlinx.coroutines.flow.collect

import com.vueo.shared.core.diagnostics.AppCrashReport
import com.vueo.shared.core.diagnostics.CrashReportStore
import com.vueo.shared.core.diagnostics.RuntimeDiagnostics

import android.app.Activity
import android.net.Uri
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.graphics.Typeface
import android.util.TypedValue
import android.os.Build
import android.os.SystemClock
import android.widget.Toast
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsInputComponent
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.key
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.ForwardingRenderer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.MediaItem as Media3MediaItem
import com.vueo.mobile.core.extensions.AddonCategory
import com.vueo.mobile.core.extensions.primaryAddonCategory
import com.vueo.mobile.core.extensions.ExtensionKind
import com.vueo.mobile.core.extensions.MediaExtension
import com.vueo.mobile.core.extensions.UnifiedMediaEngine
import com.vueo.mobile.core.extensions.SourceRanker
import com.vueo.mobile.core.extensions.SourceDiscoveryCache
import com.vueo.mobile.core.extensions.CatalogDiscoveryCache
import com.vueo.mobile.core.enrichment.MdblistClient
import com.vueo.mobile.core.enrichment.MediaRating
import com.vueo.mobile.core.enrichment.TmdbEnhancementClient
import com.vueo.shared.core.enrichment.ContentWarning
import com.vueo.shared.core.enrichment.ContentWarningRepository
import com.vueo.shared.core.detail.DetailPeoplePolicy
import com.vueo.shared.core.detail.DetailUpstreamPolicy
import com.vueo.shared.core.home.HomeCatalogPolicy
import com.vueo.shared.core.home.HomeRecommendationPolicy
import com.vueo.shared.core.search.DiscoverCatalogPolicy
import com.vueo.shared.core.search.DiscoverSortMode
import com.vueo.shared.core.search.SearchResultOrderPolicy
import com.vueo.shared.core.search.SearchMediaFilter
import com.vueo.shared.core.recommendation.RelatedContentOrchestrator
import com.vueo.shared.core.search.SearchOrchestrator
import com.vueo.shared.core.search.MediaEntityKind
import com.vueo.shared.core.search.MediaEntityTarget
import com.vueo.shared.core.source.SourceDiscoveryEngine
import com.vueo.shared.core.source.SourceDiscoveryRequest
import com.vueo.mobile.core.dna.UserDnaEngine
import com.vueo.mobile.core.dna.UserDnaPreferences
import com.vueo.mobile.core.model.CatalogRow
import com.vueo.mobile.BuildConfig
import com.vueo.mobile.R
import com.vueo.mobile.core.storage.PlaybackStore
import com.vueo.mobile.core.storage.LibraryStore
import com.vueo.mobile.core.storage.ProfileStore
import com.vueo.mobile.core.storage.VueoProfile
import com.vueo.mobile.core.storage.LibraryPlaybackEntry
import com.vueo.mobile.core.storage.PreferredQuality
import com.vueo.mobile.core.storage.PlayerOrientation
import com.vueo.mobile.core.storage.PlayerVideoFit
import com.vueo.mobile.core.storage.SettingsStore
import com.vueo.mobile.core.player.PlayerSkipKind
import com.vueo.mobile.core.player.PlayerSkipRepository
import com.vueo.mobile.core.player.PlayerSkipSegment
import com.vueo.mobile.core.player.PlayerPlaybackPhase
import com.vueo.mobile.core.player.PlayerSourceAssessment
import com.vueo.mobile.core.player.PlayerSourceAudioMatch
import com.vueo.mobile.core.player.PlayerSourcePolicy
import com.vueo.shared.core.player.PlayerTrackPolicy
import com.vueo.mobile.core.player.PlayerSourceRecoverySession
import com.vueo.mobile.core.player.PLAYER_REBUFFER_TIMEOUT_MS
import com.vueo.mobile.core.player.PLAYER_RECOVERY_SOURCE_TIMEOUT_MS
import com.vueo.mobile.core.player.PLAYER_STARTUP_TIMEOUT_MS
import com.vueo.mobile.core.storage.VueoDataMigration
import com.vueo.mobile.core.update.VueoUpdateManager
import com.vueo.mobile.core.model.SubtitleTrack
import com.vueo.mobile.core.plugin.PluginStore
import com.vueo.mobile.core.plugin.ProviderCodeSyncManager
import com.vueo.mobile.core.plugin.ProviderCodeStore
import com.vueo.mobile.core.plugin.ProviderHealthStatus
import com.vueo.mobile.core.plugin.ProviderHealthRecord
import com.vueo.mobile.core.plugin.PluginHealthStore
import com.vueo.mobile.core.plugin.PluginSourceEngine
import com.vueo.mobile.core.plugin.PluginRepositoryDescriptor
import com.vueo.mobile.core.plugin.PluginRepositoryClient
import com.vueo.mobile.core.model.EpisodeItem
import com.vueo.mobile.core.model.MediaCompany
import com.vueo.mobile.core.model.MediaItem
import com.vueo.shared.core.media.MediaTypePolicy
import com.vueo.mobile.core.model.MediaPerson
import com.vueo.mobile.core.model.StreamSource
import com.vueo.mobile.core.storage.AddonStore
import com.vueo.mobile.ui.components.NetworkImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private enum class AppTab {
    HOME,
    SEARCH,
    LIBRARY,
    SETTINGS,
}

private enum class AppSurface {
    STARTUP,
    ROOT,
    CATALOG,
    COLLECTION_FOLDER,
    DETAILS,
    ENTITY_RESULTS,
    PROFILES,
}

internal enum class DetailSurface {
    DETAILS,
    SOURCES,
    PLAYER,
}

private enum class SettingsPage {
    ROOT,
    VUEO_SYNC,
    CONTENT_MANAGER,
    ADDONS,
    PLUGINS,
    CATALOG_ORDER,
    COLLECTIONS,
    ENHANCEMENTS,
    TRAKT,
    TMDB,
    MDBLIST,
    GEMINI,
    PLAYBACK,
    SUBTITLES,
    SOURCES,
    APPEARANCE,
    DATA_STORAGE,
    ABOUT,
}

private fun parentSettingsPage(
    page: SettingsPage,
): SettingsPage =
    when (page) {
        SettingsPage.ADDONS,
        SettingsPage.PLUGINS,
        SettingsPage.COLLECTIONS,
        SettingsPage.CATALOG_ORDER ->
            SettingsPage.CONTENT_MANAGER

        SettingsPage.TRAKT,
        SettingsPage.TMDB,
        SettingsPage.MDBLIST,
        SettingsPage.GEMINI ->
            SettingsPage.ENHANCEMENTS

        SettingsPage.ROOT ->
            SettingsPage.ROOT

        else ->
            SettingsPage.ROOT
    }

internal enum class SearchTypeFilter(
    val label: String,
) {
    ALL("All"),
    MOVIES("Movies"),
    SERIES("Series"),
    ANIME("Anime"),
}

internal enum class SearchSortMode(
    val label: String,
) {
    POPULAR("Popular"),
    TRENDING("Trending"),
    NEWEST("Newest"),
}

internal enum class SearchMode(
    val label: String,
) {
    TITLE("Title"),
    ACTOR("Actor"),
}

// Persist only detail identity and lightweight artwork; playback state stays transient.
private val MobileDetailSaver = Saver<MediaItem?, ArrayList<String>>(
    save = { ArrayList(MobileNavigationSnapshot.media(it)) },
    restore = { MobileNavigationSnapshot.restoreMedia(it) },
)
private val MobileDetailStackSaver = Saver<List<MediaItem>, ArrayList<String>>(
    save = { ArrayList(MobileNavigationSnapshot.stack(it)) },
    restore = { MobileNavigationSnapshot.restoreStack(it) },
)
private val MobileEntitySaver = Saver<MediaEntityTarget?, ArrayList<String>>(
    save = { target ->
        arrayListOf(target?.kind?.name.orEmpty(), target?.name?.take(512).orEmpty(),
            target?.tmdbId?.toString().orEmpty())
    },
    restore = { fields ->
        if (fields.size != 3 || fields[1].isBlank() || fields[1].length > 512) null
        else MediaEntityKind.entries.firstOrNull { it.name == fields[0] }?.let {
            MediaEntityTarget(it, fields[1], fields[2].toLongOrNull())
        }
    },
)

@Composable
fun VueoApp(
    pendingAccountReturn: String? = null,
    onPendingAccountReturnConsumed: () -> Unit = {},
    pendingAddonManifestUrl: String? = null,
    onPendingAddonManifestConsumed: () -> Unit = {},
) {
    val context = LocalContext.current
    var pendingCrash by remember { mutableStateOf<AppCrashReport?>(null) }
    var showCrashDiagnostics by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        pendingCrash = withContext(Dispatchers.IO) {
            runCatching { CrashReportStore.pending(context.applicationContext) }.getOrNull()
        }
    }

    val engine = remember { UnifiedMediaEngine { ProfileStore(context.applicationContext).kidsAgeLimit() } }
    val settingsRetainedState =
        rememberMobileSettingsRetainedState()
    val store = remember {
        AddonStore(context.applicationContext)
    }
    val addonConfigurationReloader = remember(engine, store) {
        com.vueo.mobile.core.extensions.MobileAddonConfigurationReloader(engine, store)
    }
    var addonListRevision by remember { mutableIntStateOf(0) }
    suspend fun reloadConfiguredAddons() {
        val summary = addonConfigurationReloader.reload(onInstalled = {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main.immediate) {
                addonListRevision++
            }
        })
        com.vueo.shared.core.diagnostics.PerformanceDiagnostics.captureRuntimeEvent(
            "ADDON_CONFIG_RELOAD platform=Mobile loaded=${summary.loaded} reused=${summary.reused} " +
                "removed=${summary.removed} failed=${summary.failed} conflicts=${summary.conflicts}",
        )
    }

    val pluginStore = remember {
        PluginStore(context.applicationContext)
    }
    val libraryStore = remember {
        LibraryStore(
            context.applicationContext
        )
    }
    val profileStore = remember {
        ProfileStore(
            context.applicationContext
        )
    }
    val settingsStore = remember {
        SettingsStore(
            context.applicationContext
        )
    }

    LaunchedEffect(settingsStore) {
        VueoPalette.applyTheme(
            settingsStore.appTheme()
        )
        VueoPalette.applyAccent(
            settingsStore.appAccent()
        )
    }
    val providerCodeSync = remember {
        ProviderCodeSyncManager(
            context.applicationContext
        )
    }

    var profileVersion by remember {
        mutableIntStateOf(0)
    }
    val navigationProfile = remember(profileVersion) { profileStore.activeProfile() }
    val navigationOwner = navigationProfile.mobileHomeStateKey()
    var savedNavigationOwner by rememberSaveable { mutableStateOf(navigationOwner) }
    var searchMode by rememberSaveable(navigationOwner) { mutableStateOf(SearchMode.TITLE) }
    var selectedTab by rememberSaveable(navigationOwner) { mutableStateOf(AppTab.HOME) }
    var settingsPage by rememberSaveable(navigationOwner) { mutableStateOf(SettingsPage.ROOT) }
    var accountReturnHint by remember { mutableStateOf<String?>(null) }
    var searchQuery by rememberSaveable(navigationOwner) {
        mutableStateOf("")
    }
    var searchTypeFilter by rememberSaveable(navigationOwner) {
        mutableStateOf(
            SearchTypeFilter.ALL
        )
    }
    var searchSortMode by rememberSaveable(navigationOwner) {
        mutableStateOf(
            SearchSortMode.POPULAR
        )
    }
    var searchGenre by rememberSaveable(navigationOwner) {
        mutableStateOf<String?>(
            null
        )
    }
    val searchListState =
        rememberLazyListState()
    var contentVersion by remember { mutableIntStateOf(0) }
    var booting by remember {
        mutableStateOf(true)
    }
    var addonsPrepared by remember {
        mutableStateOf(false)
    }
    var startupDestinationResolved by remember {
        mutableStateOf(false)
    }
    var selectedMedia by rememberSaveable(navigationOwner, stateSaver = MobileDetailSaver) {
        mutableStateOf<MediaItem?>(null)
    }
    var selectedEntityTarget by rememberSaveable(navigationOwner, stateSaver = MobileEntitySaver) {
        mutableStateOf<MediaEntityTarget?>(null)
    }
    var selectedCollectionId by rememberSaveable(navigationOwner) { mutableStateOf<String?>(null) }
    var selectedFolderId by rememberSaveable(navigationOwner) { mutableStateOf<String?>(null) }
    val collectionUiState = rememberSaveableStateHolder()
    var selectedCatalogRow by remember {
        mutableStateOf<CatalogRow?>(null)
    }
    var mediaBackStack by rememberSaveable(navigationOwner, stateSaver = MobileDetailStackSaver) {
        mutableStateOf<List<MediaItem>>(
            emptyList()
        )
    }
    var libraryVersion by remember {
        mutableIntStateOf(0)
    }
    // UI restoration belongs to a local profile and its current Kids policy.
    // Retain presentation data separately from Bundle-safe scroll coordinates.
    val homeUiState = rememberSaveableStateHolder()
    val homeRetainedStates = remember { mutableMapOf<String, MobileHomeRetainedState>() }
    var savedHomeKeys by rememberSaveable { mutableStateOf(emptyList<String>()) }
    val homeProfiles = remember(profileVersion) { profileStore.profiles() }
    val homeProfile = remember(profileVersion) { profileStore.activeProfile() }
    val homeStateKey = homeProfile.mobileHomeStateKey()
    val validHomeKeys = homeProfiles.map { it.mobileHomeStateKey() }.toSet()
    val homeRetainedState = remember(homeStateKey) {
        homeRetainedStates.getOrPut(homeStateKey) { MobileHomeRetainedState() }
    }
    LaunchedEffect(validHomeKeys, homeStateKey) {
        val obsoleteKeys = (savedHomeKeys + homeRetainedStates.keys).toSet() - validHomeKeys
        obsoleteKeys.forEach { obsolete ->
            homeUiState.removeState(obsolete)
            homeRetainedStates.remove(obsolete)
        }
        savedHomeKeys = (savedHomeKeys.filter { it in validHomeKeys } + homeStateKey).distinct()
    }

    var showProfilePicker by rememberSaveable {
        mutableStateOf(false)
    }
    var profilePickerOpenedFromApp by rememberSaveable {
        mutableStateOf(false)
    }
    var playFeatured by remember { mutableStateOf(false) }
    var selectedLibraryEntry by remember {
        mutableStateOf<
            LibraryPlaybackEntry?
        >(null)
    }

    // rememberSaveable inputs reset live state, but Android restoration does not validate
    // old inputs. Keep the tree hidden until the saved owner has been checked too.
    LaunchedEffect(navigationOwner) {
        if (savedNavigationOwner != navigationOwner) {
            playFeatured = false
            selectedTab = AppTab.HOME
            settingsPage = SettingsPage.ROOT
            searchQuery = ""
            searchTypeFilter = SearchTypeFilter.ALL
            searchSortMode = SearchSortMode.POPULAR
            searchGenre = null
            searchMode = SearchMode.TITLE
            searchListState.scrollToItem(0)
            selectedMedia = null
            selectedEntityTarget = null
            selectedCatalogRow = null
            selectedLibraryEntry = null
            mediaBackStack = emptyList()
            savedNavigationOwner = navigationOwner
        }
    }
    val restoringDetail = remember { selectedMedia != null }

    val vueoSync = remember { com.vueo.shared.core.sync.VueoSyncService.get(context) }
    DisposableEffect(vueoSync) { vueoSync.setForeground(true); onDispose { vueoSync.setForeground(false) } }
    LaunchedEffect(vueoSync) {
        vueoSync.dataRevision.collect { revision ->
            if (revision > 0) libraryVersion++
        }
    }
    LaunchedEffect(vueoSync) {
        vueoSync.profileRevision.collect { revision -> if (revision > 0) profileVersion++ }
    }
    LaunchedEffect(vueoSync) {
        vueoSync.integrationRevision.collect { revision ->
            if (revision > 0) {
                withContext(Dispatchers.IO) {
                    CatalogDiscoveryCache.clearAll(context.applicationContext)
                    SourceDiscoveryCache.clearAll()
                }
                contentVersion++
            }
        }
    }
    LaunchedEffect(vueoSync) {
        vueoSync.configurationRevision.collect { revision ->
            if (revision > 0) {
                withContext(Dispatchers.IO) {
                    reloadConfiguredAddons()
                    providerCodeSync.syncMissing(pluginStore.repositories())
                    CatalogDiscoveryCache.clearAll(context.applicationContext)
                    SourceDiscoveryCache.clearAll()
                }
                contentVersion++
            }
        }
    }

    LaunchedEffect(pendingAccountReturn, booting, startupDestinationResolved, showProfilePicker) {
        if (pendingAccountReturn != null && !booting && startupDestinationResolved && !showProfilePicker) {
            selectedMedia = null
            selectedEntityTarget = null
            selectedCatalogRow = null
            selectedLibraryEntry = null
            mediaBackStack = emptyList()
            selectedTab = AppTab.SETTINGS
            settingsPage = SettingsPage.VUEO_SYNC
            accountReturnHint = pendingAccountReturn
            onPendingAccountReturnConsumed()
        }
    }

    LaunchedEffect(
        pendingAddonManifestUrl,
        booting,
        startupDestinationResolved,
        showProfilePicker,
    ) {
        if (
            pendingAddonManifestUrl != null &&
            !booting &&
            startupDestinationResolved &&
            !showProfilePicker
        ) {
            selectedMedia = null
            selectedEntityTarget = null
            selectedCatalogRow = null
            selectedLibraryEntry = null
            mediaBackStack = emptyList()
            selectedTab = AppTab.SETTINGS
            settingsPage = SettingsPage.ADDONS
        }
    }

    LaunchedEffect(Unit) {
        VueoDataMigration.migrateIfNeeded(
            context.applicationContext
        )

        profileStore.ensureDefaultProfile()
        if (!showProfilePicker) {
            showProfilePicker = profileStore.shouldShowPickerOnStartup()
            profilePickerOpenedFromApp = false
        }
        profileVersion++
        startupDestinationResolved = true

        CatalogDiscoveryCache
            .restoreHome(
                context.applicationContext
            )

        SourceDiscoveryCache
            .clearExpired()

        if (
            settingsStore
                .automaticUpdateChecksEnabled()
        ) {
            launch {
                VueoUpdateManager.check(
                    context = context.applicationContext,
                    force = false,
                )
            }
        }

        store.seedDevelopmentDefaultsIfNeeded()

        launch {
            pluginStore.seedDevelopmentDefaultsIfNeeded()
            providerCodeSync.syncMissing(
                pluginStore.repositories()
            )
        }

        // Local startup is complete at this point. Do not hold the entire app on
        // remote addon manifests; cached Home can render while addon preparation
        // runs through the same bounded coordinator as account/import reloads.
        booting = false
        contentVersion++

        launch {
            reloadConfiguredAddons()

            // Trigger one catalog/search refresh after the configured addon set
            // has settled. Avoid restarting Home once per manifest.
            addonsPrepared = true
            contentVersion++
        }
    }

    BackHandler(
        enabled =
            !booting &&
                showProfilePicker &&
                profilePickerOpenedFromApp,
    ) {
        showProfilePicker = false
        profilePickerOpenedFromApp = false
    }

    BackHandler(
        enabled =
            !booting &&
                !showProfilePicker &&
                selectedMedia == null &&
                selectedCatalogRow != null,
    ) {
        selectedCatalogRow = null
    }

    BackHandler(
        enabled =
            !booting &&
                !showProfilePicker &&
                selectedMedia == null &&
                selectedCatalogRow == null &&
                (
                    selectedTab != AppTab.HOME ||
                        settingsPage != SettingsPage.ROOT
                ),
    ) {
        if (
            selectedTab == AppTab.SETTINGS &&
            settingsPage != SettingsPage.ROOT
        ) {
            settingsPage =
                parentSettingsPage(
                    settingsPage
                )
        } else {
            playFeatured = false
            selectedTab = AppTab.HOME
            settingsPage = SettingsPage.ROOT
        }
    }

    var transitionCatalogRow by remember {
        mutableStateOf<CatalogRow?>(null)
    }
    var transitionMedia by remember {
        mutableStateOf<MediaItem?>(null)
    }
    var transitionLibraryEntry by remember {
        mutableStateOf<LibraryPlaybackEntry?>(null)
    }

    selectedCatalogRow?.let { row ->
        transitionCatalogRow = row
    }
    selectedMedia?.let { media ->
        transitionMedia = media
        transitionLibraryEntry = selectedLibraryEntry
    }

    val appSurface =
        when {
            !startupDestinationResolved || savedNavigationOwner != navigationOwner -> AppSurface.STARTUP
            showProfilePicker -> AppSurface.PROFILES
            restoringDetail && !addonsPrepared && selectedMedia != null -> AppSurface.STARTUP
            selectedEntityTarget != null -> AppSurface.ENTITY_RESULTS
            selectedMedia != null -> AppSurface.DETAILS
            selectedCatalogRow != null -> AppSurface.CATALOG
            selectedCollectionId != null && selectedFolderId != null -> AppSurface.COLLECTION_FOLDER
            else -> AppSurface.ROOT
        }

    AnimatedContent(
        targetState = appSurface,
        transitionSpec = {
            if (
                targetState == AppSurface.ROOT && initialState == AppSurface.DETAILS
            ) {
                vueoDetailsRootBackTransition()
            } else if (
                targetState == AppSurface.ROOT &&
                initialState in setOf(
                    AppSurface.DETAILS,
                    AppSurface.CATALOG,
                    AppSurface.ENTITY_RESULTS,
                )
            ) {
                vueoScreenBackTransition()
            } else {
                vueoScreenForwardTransition()
            }
        },
        modifier = Modifier.fillMaxSize(),
        label = "Tiveo app surface transition",
    ) { surface ->
        when (surface) {
            AppSurface.STARTUP -> {
                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(
                                VueoPalette.Background
                            ),
                    contentAlignment = Alignment.Center,
                ) {
                    VueoBrandLockup()
                }
            }

            AppSurface.PROFILES -> {
                WhosWatchingScreen(
                    profileStore = profileStore,
                    profileVersion = profileVersion,
                    onProfileSelected = {
                        val resumeSavedRoute = MobileNavigationSnapshot.mayResumeRoute(
                            savedNavigationOwner,
                            profileStore.activeProfile().mobileHomeStateKey(),
                            profilePickerOpenedFromApp,
                        )
                        if (!resumeSavedRoute) {
                            selectedMedia = null
                            selectedEntityTarget = null
                            selectedCatalogRow = null
                            selectedLibraryEntry = null
                            mediaBackStack = emptyList()
                            selectedTab =
                                if (profilePickerOpenedFromApp) {
                                    AppTab.SETTINGS
                                } else {
                                    AppTab.HOME
                                }
                            settingsPage = SettingsPage.ROOT
                        }
                        libraryVersion++
                        profileVersion++
                        showProfilePicker = false
                        profilePickerOpenedFromApp = false
                    },
                    onProfilesChanged = {
                        profileVersion++
                        libraryVersion++
                    },
                )
            }

            AppSurface.COLLECTION_FOLDER -> {
                val collectionId = selectedCollectionId
                val folderId = selectedFolderId
                if (collectionId != null && folderId != null) {
                    collectionUiState.SaveableStateProvider("$navigationOwner:$collectionId:$folderId") {
                        com.vueo.shared.collections.ui.CollectionFolderScreen(
                            engine = engine, profileId = navigationProfile.id,
                            collectionId = collectionId, folderId = folderId,
                            contentRevision = contentVersion,
                            image = { url, label, modifier -> com.vueo.mobile.ui.components.NetworkImage(url, label, modifier) },
                            onBack = { selectedCollectionId = null; selectedFolderId = null },
                            onMedia = { item -> selectedLibraryEntry = null; mediaBackStack = emptyList(); selectedMedia = item },
                        )
                    }
                }
            }

            AppSurface.CATALOG -> {
                transitionCatalogRow?.let { row ->
                    CatalogSeeAllScreen(
                        row = row,
                        libraryStore = libraryStore,
                        libraryVersion = libraryVersion,
                        onLibraryChanged = {
                            libraryVersion++
                        },
                        onBack = {
                            selectedCatalogRow = null
                        },
                        onMediaClick = { item ->
                            selectedLibraryEntry = null
                            mediaBackStack = emptyList()
                            selectedMedia = item
                        },
                    )
                }
            }

            AppSurface.ENTITY_RESULTS -> {
                selectedEntityTarget?.let { target ->
                    MediaEntityResultsScreen(
                        engine = engine,
                        target = target,
                        tmdbApiKey = pluginStore.tmdbApiKey(),
                        onBack = {
                            selectedEntityTarget = null
                        },
                        onMediaClick = { next ->
                            selectedMedia?.let { current ->
                                mediaBackStack = mediaBackStack + current
                            }
                            selectedLibraryEntry = null
                            selectedMedia = next
                            selectedEntityTarget = null
                        },
                    )
                }
            }

            AppSurface.DETAILS -> {
                transitionMedia?.let { detailItem ->
                    MediaDetailsScreen(
                        engine = engine,
                        settingsStore = settingsStore,
                        active = selectedMedia != null,
                        initialItem = detailItem,
                        initialLibraryEntry = transitionLibraryEntry,
                        playOnEntry = playFeatured && selectedMedia != null,
                        onPlayRequestHandled = { playFeatured = false },
                        onLibraryChanged = {
                            libraryVersion++
                        },
                        onBack = {
                            playFeatured = false
                            val previous =
                                mediaBackStack.lastOrNull()

                            if (previous == null) {
                                selectedMedia = null
                                selectedLibraryEntry = null
                            } else {
                                selectedMedia = previous
                                mediaBackStack =
                                    mediaBackStack.dropLast(1)
                            }
                        },
                        onMediaClick = { next ->
                            selectedMedia?.let { current ->
                                mediaBackStack =
                                    mediaBackStack + current
                            }

                            selectedLibraryEntry = null
                            selectedMedia = next
                        },
                        onEntityClick = { target ->
                            selectedEntityTarget = target
                        },
                    )
                }
            }

            AppSurface.ROOT -> Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Surface(color = Color(0xFF101010)) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().height(60.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    fun selectTab(tab: AppTab) {
                        selectedCatalogRow = null
                        selectedTab = tab
                        settingsPage = SettingsPage.ROOT
                    }
                    BottomTab(AppTab.HOME, selectedTab, Icons.Default.Home, "Home", ::selectTab)
                    BottomTab(AppTab.SEARCH, selectedTab, Icons.Default.Search, "Search", ::selectTab)
                    BottomTab(AppTab.LIBRARY, selectedTab, Icons.Default.VideoLibrary, "My List", ::selectTab)
                    BottomTab(AppTab.SETTINGS, selectedTab, Icons.Default.Settings, "Settings", ::selectTab)
                }
            }
        },
    ) { padding ->
        val layoutDirection = LocalLayoutDirection.current
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    VueoPalette.Background
                )
                .padding(
                    start = padding.calculateStartPadding(layoutDirection),
                    end = padding.calculateEndPadding(layoutDirection),
                    bottom = padding.calculateBottomPadding(),
                )
                .clipToBounds(),
        ) {
            AnimatedContent(
                targetState = selectedTab to settingsPage,
                transitionSpec = {
                    vueoTabCrossTransition()
                },
                modifier = Modifier.fillMaxSize(),
                label = "Tiveo main navigation transition",
            ) { (currentTab, currentSettingsPage) ->
                Box(
                    Modifier.fillMaxSize()
                        .padding(top = if (currentTab == AppTab.HOME) 0.dp else padding.calculateTopPadding())
                        .clipToBounds(),
                ) {
                    when (currentTab) {
                    AppTab.HOME -> key(homeStateKey) {
                        homeUiState.SaveableStateProvider(homeStateKey) {
                            HomeScreen(
                                engine = engine,
                                retainedState = homeRetainedState,
                                activeProfileId = homeProfile.id,
                                contentVersion = contentVersion,
                                booting = booting,
                                addonsPrepared = addonsPrepared,
                                libraryStore = libraryStore,
                                libraryVersion = libraryVersion,
                                onLibraryChanged = {
                                    libraryVersion++
                                },
                                onOpenContentManager = {
                                    selectedTab =
                                        AppTab.SETTINGS
                                    settingsPage =
                                        SettingsPage
                                            .CONTENT_MANAGER
                                },
                                profileAvatar = {
                                    IconButton(onClick = {
                                        profilePickerOpenedFromApp = true
                                        showProfilePicker = true
                                    }) {
                                        ProfileAvatar(profile = navigationProfile, size = 30)
                                    }
                                },
                                onPlayFeatured = { item ->
                                    mediaBackStack = emptyList()
                                    selectedLibraryEntry = null
                                    playFeatured = true
                                    selectedMedia = item
                                },
                                onMediaClick = {
                                    playFeatured = false
                                    mediaBackStack =
                                        emptyList()
                                    selectedLibraryEntry =
                                        null
                                    selectedMedia = it
                                },
                                onPlaybackClick = {
                                    entry ->
                                    mediaBackStack =
                                        emptyList()
                                    selectedLibraryEntry =
                                        entry
                                    selectedMedia =
                                        entry.media
                                },
                                onOpenCollection = { collection, folder ->
                                    selectedCollectionId = collection; selectedFolderId = folder
                                },
                                onSeeAll = {
                                    row ->
                                    selectedCatalogRow =
                                        row
                                },
                            )
                        }
                    }

                    AppTab.SEARCH -> SearchScreen(
                        engine = engine,
                        contentVersion =
                            contentVersion,
                        profileVersion = profileVersion,
                        booting = booting,
                        query = searchQuery,
                        searchMode = searchMode,
                        onSearchModeChange = { searchMode = it },
                        onQueryChange = {
                            searchQuery = it
                        },
                        typeFilter =
                            searchTypeFilter,
                        onTypeFilterChange = {
                            searchTypeFilter = it
                        },
                        sortMode =
                            searchSortMode,
                        onSortModeChange = {
                            searchSortMode = it
                        },
                        genre = searchGenre,
                        onGenreChange = {
                            searchGenre = it
                        },
                        listState =
                            searchListState,
                        onMediaClick = {
                            mediaBackStack =
                                emptyList()
                            selectedLibraryEntry =
                                null
                            selectedMedia = it
                        },
                    )

                    AppTab.LIBRARY -> LibraryScreen(
                        store =
                            libraryStore,
                        activeProfile =
                            profileStore.activeProfile(),
                        version =
                            libraryVersion,
                        onVersionChanged = {
                            libraryVersion++
                        },
                        onMediaClick = {
                            mediaBackStack =
                                emptyList()
                            selectedLibraryEntry =
                                null
                            selectedMedia = it
                        },
                        onPlaybackClick = {
                            entry ->

                            mediaBackStack =
                                emptyList()
                            selectedLibraryEntry =
                                entry
                            selectedMedia =
                                entry.media
                        },
                    )

                    AppTab.SETTINGS -> when (
                        currentSettingsPage
                    ) {
                        SettingsPage.ROOT ->
                            VueoSettingsHub(
                                engine = engine,
                                settingsStore = settingsStore,
                                profileStore = profileStore,
                                retainedState = settingsRetainedState,
                                profileVersion = profileVersion,
                                libraryVersion = libraryVersion,
                                contentVersion = contentVersion,
                                onProfiles = {
                                    showProfilePicker = true
                                    profilePickerOpenedFromApp = true
                                },
                                onSync = { settingsPage = SettingsPage.VUEO_SYNC },
                                onContentManager = {
                                    settingsPage = SettingsPage.CONTENT_MANAGER
                                },
                                onEnhancements = {
                                    settingsPage = SettingsPage.ENHANCEMENTS
                                },
                                onPlayback = {
                                    settingsPage = SettingsPage.PLAYBACK
                                },
                                onSubtitles = {
                                    settingsPage = SettingsPage.SUBTITLES
                                },
                                onSources = {
                                    settingsPage = SettingsPage.SOURCES
                                },
                                onAppearance = {
                                    settingsPage = SettingsPage.APPEARANCE
                                },
                                onDataStorage = {
                                    settingsPage = SettingsPage.DATA_STORAGE
                                },
                                onAbout = {
                                    settingsPage = SettingsPage.ABOUT
                                },
                            )

                        SettingsPage.VUEO_SYNC -> VueoSyncSettingsScreen(onBack = { settingsPage = SettingsPage.ROOT }, returnHint = accountReturnHint)

                        SettingsPage.CONTENT_MANAGER ->
                            ContentManagerScreen(
                                engine = engine,
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                                onAddons = {
                                    settingsPage = SettingsPage.ADDONS
                                },
                                onPlugins = {
                                    settingsPage = SettingsPage.PLUGINS
                                },
                                onCollections = { settingsPage = SettingsPage.COLLECTIONS },
                                onCatalogOrder = {
                                    settingsPage =
                                        SettingsPage.CATALOG_ORDER
                                },
                            )

                        SettingsPage.ADDONS ->
                            AddonsScreen(
                                engine = engine,
                                store = store,
                                contentVersion = contentVersion + addonListRevision,
                                pendingInstallManifestUrl = pendingAddonManifestUrl,
                                onPendingInstallConsumed = onPendingAddonManifestConsumed,
                                onContentChanged = {
                                    contentVersion++
                                },
                                onBack = {
                                    settingsPage = SettingsPage.CONTENT_MANAGER
                                },
                            )

                        SettingsPage.PLUGINS ->
                            PluginsScreen(
                                onBack = {
                                    settingsPage = SettingsPage.CONTENT_MANAGER
                                },
                            )
                        SettingsPage.COLLECTIONS ->
                            com.vueo.shared.collections.ui.CollectionManagerScreen(
                                engine = engine, profileId = navigationProfile.id,
                                onBack = { settingsPage = SettingsPage.CONTENT_MANAGER },
                                image = { url, label, modifier -> com.vueo.mobile.ui.components.NetworkImage(url, label, modifier) },
                            )
                        SettingsPage.CATALOG_ORDER ->
                            CatalogOrderScreen(
                                engine = engine,
                                store = store,
                                contentVersion =
                                    contentVersion,
                                onContentChanged = {
                                    contentVersion++
                                },
                                onBack = {
                                    settingsPage =
                                        SettingsPage.CONTENT_MANAGER
                                },
                            )

                        SettingsPage.ENHANCEMENTS ->
                            EnhancementsSettingsScreen(
                                settingsStore = settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                                onTrakt = {
                                    settingsPage = SettingsPage.TRAKT
                                },
                                onTmdb = {
                                    settingsPage = SettingsPage.TMDB
                                },
                                onMdblist = {
                                    settingsPage = SettingsPage.MDBLIST
                                },
                                onGemini = {
                                    settingsPage = SettingsPage.GEMINI
                                },
                            )

                        SettingsPage.TRAKT ->
                            TraktEnhancementSettingsScreen(
                                onBack = { settingsPage = SettingsPage.ENHANCEMENTS },
                            )

                        SettingsPage.TMDB ->
                            TmdbEnhancementSettingsScreen(
                                settingsStore = settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ENHANCEMENTS
                                },
                            )

                        SettingsPage.MDBLIST ->
                            MdblistEnhancementSettingsScreen(
                                settingsStore = settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ENHANCEMENTS
                                },
                            )


                        SettingsPage.GEMINI ->
                            GeminiEnhancementSettingsScreen(
                                onBack = { settingsPage = SettingsPage.ENHANCEMENTS },
                            )

                        SettingsPage.PLAYBACK ->
                            PlaybackSettingsScreen(
                                settingsStore = settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                            )

                        SettingsPage.SUBTITLES ->
                            SubtitleSettingsScreen(
                                settingsStore = settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                            )

                        SettingsPage.SOURCES ->
                            SourceSettingsScreen(
                                settingsStore = settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                            )

                        SettingsPage.APPEARANCE ->
                            AppearanceSettingsScreen(
                                settingsStore =
                                    settingsStore,
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                            )

                        SettingsPage.DATA_STORAGE ->
                            DataStorageSettingsScreen(
                                libraryStore = libraryStore,
                                settingsStore = settingsStore,
                                onLibraryChanged = {
                                    libraryVersion++
                                },
                                onCatalogCacheCleared = {
                                    contentVersion++
                                },
                                onPersistentDataChanged = {
                                    store.seedDevelopmentDefaultsIfNeeded()
                                    pluginStore.seedDevelopmentDefaultsIfNeeded()
                                    reloadConfiguredAddons()

                                    providerCodeSync.syncMissing(
                                        pluginStore.repositories()
                                    )

                                    profileStore.ensureDefaultProfile()
                                    VueoPalette.applyAccent(
                                        settingsStore.appAccent()
                                    )
                                    selectedLibraryEntry = null
                                    contentVersion++
                                    libraryVersion++
                                    profileVersion++
                                },
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                            )

                        SettingsPage.ABOUT ->
                            AboutVueoSettingsScreen(
                                onBack = {
                                    settingsPage = SettingsPage.ROOT
                                },
                            )
                    }
                }
                }
        }
        }
    }
        }
    }
    LaunchedEffect(appSurface, selectedTab) {
        RuntimeDiagnostics.recordScreen("Mobile ${appSurface.name} / ${selectedTab.name}")
    }
    if (startupDestinationResolved && !booting && !showProfilePicker) {
        pendingCrash?.let { report ->
            MobileCrashRecoveryPopup(
                report = report,
                onClosed = { pendingCrash = null },
                onOpenDiagnostics = {
                    pendingCrash = null
                    showCrashDiagnostics = true
                },
            )
        }
    }
    if (showCrashDiagnostics) {
        RuntimeDiagnosticsDialog(onDismiss = { showCrashDiagnostics = false })
    }

}

@Composable
private fun RowScope.BottomTab(
    tab: AppTab,
    selected: AppTab,
    icon: ImageVector,
    label: String,
    onSelect: (AppTab) -> Unit,
) {
    NavigationBarItem(
        selected = selected == tab,
        onClick = {
            onSelect(tab)
        },
        icon = {
            Icon(
                imageVector = icon,
                contentDescription =
                    label,
                modifier =
                    Modifier.size(
                        24.dp
                    ),
            )
        },
        label = {
            Text(
                label,
                fontSize = 10.sp,
                fontWeight =
                    if (
                        selected == tab
                    ) {
                        FontWeight.Bold
                    } else {
                        FontWeight.Medium
                    },
            )
        },
        colors =
            NavigationBarItemDefaults
                .colors(
                    selectedIconColor =
                        Color.White,
                    selectedTextColor =
                        Color.White,
                    indicatorColor =
                        Color.Transparent,
                    unselectedIconColor =
                        VueoPalette.Muted,
                    unselectedTextColor =
                        VueoPalette.Muted,
                ),
    )
}

private fun VueoProfile.mobileHomeStateKey(): String =
    "home:$id:${if (isKids) "kids:$kidsMaxAge" else "standard"}"
